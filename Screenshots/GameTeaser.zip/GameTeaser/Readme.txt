by Dave Vanderzee, Zach Dugas, Miles Konstantin, Devin Comeau, and Pasha Chorba


	These are some screenshots of the framework we have working now. We are in the process of adding the script Devin is working on into the game. Among other things we are in the process of working on several more mini games. Our ideas thus far are evolving but rough brainstorming gave us:
	Jigsaw puzzle - constructing your initial galactic map.
	Simple physics minigames
	Light puzzle - one button affects multiple lights, get 			them all in an on/off state (potentially more than 			just 2 states)
	Hacking minigame - clicking on certain words in a terminal
	Logic games - various riddles
	Helicopter mini-game for flying your spaceship
	Alternatively asteroids


We will continue updating you on our progress in class.